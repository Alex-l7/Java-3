package com.geekbrains.server;

public class MainServer {
    public static void main(String[] args) {
        new Server();
    }
}
