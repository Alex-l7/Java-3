package com.geekbrains.client;

public interface Callback {
    void callback(Object... args);
}
